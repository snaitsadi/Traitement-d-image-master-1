#define SED_BLACKBODY_MISSINGCODE *result = c1 + c2;

#define XYZ_SRGB_R_MISSINGCODE  return 0.0;
#define XYZ_SRGB_G_MISSINGCODE  return 0.0;
#define XYZ_SRGB_B_MISSINGCODE  return 0.0;
#define XYZ_FROM_SED_MISSINGCODE ((void)0);
#define XYZ_GET_K_FROM_S_MISSINGCODE float k = *s;

#define PRINT_GMCC_COLORS_MISSINGCODE ((void)0);


