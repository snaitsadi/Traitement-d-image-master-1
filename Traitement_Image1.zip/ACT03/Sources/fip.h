#ifndef FIP_H
#define FIP_H

#include <math.h>
#include <imago2.h>
#include <stdlib.h>
#include <stdbool.h>

#define K 0.15

extern void fip_save_image_spectrum(double *spectrum, int width, int height, char *name, bool phase);

extern void fip_as_cut(double *spectrum, int width, int height, int min, int max, int mode);

extern void fip_as_notch(double *spectrum, int width, int height, int u, int v, int r, float k);

#endif  /* FIP_H */
