
#define L_SET_BBOX_MISSINGCODE (void) 0;
#define L_IS_INSIDE_DISK_MISSINGCODE return false;

#define STRELM_DISK_GETMIN_MISSINGCODE return 0;
#define STRELM_DISK_GETMAX_MISSINGCODE return 255;

#define L_DIFF_MISSINGCODE (void)0;

#define MMIP_DISK_EROSION_MISSINGCODE return result;
#define MMIP_DISK_DILATION_MISSINGCODE return malloc(width*height*sizeof(unsigned char));
#define MMIP_DISK_OPENING_MISSINGCODE return malloc(width*height*sizeof(unsigned char));
#define MMIP_DISK_CLOSING_MISSINGCODE return malloc(width*height*sizeof(unsigned char));

#define MMIP_DISK_BGRAD_MISSINGCODE return malloc(width*height*sizeof(unsigned char));
#define MMIP_DISK_IGRAD_MISSINGCODE return malloc(width*height*sizeof(unsigned char));
#define MMIP_DISK_OGRAD_MISSINGCODE return malloc(width*height*sizeof(unsigned char));

