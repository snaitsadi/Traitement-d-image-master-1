#ifndef HYSTERESIS_H
#define HYSTERESIS_H

extern unsigned char *hysteresis_thr(unsigned char *channel, int width, int height, int th_low, int th_high);
#endif  /* HYSTERESIS_H */
