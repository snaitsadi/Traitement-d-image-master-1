#ifndef IMG_H
#define IMG_H

#include <imago2.h>

extern struct img_pixmap *img_load_gl_image(char *file_name);

#endif  /* IMG_H */
