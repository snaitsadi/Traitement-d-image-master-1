#ifndef DERICHE_H
#define DERICHE_H

extern float *deriche_apply_s(float *channel, int width, int height, float alpha);
extern float *deriche_apply_d(float *channel, int width, int height, float alpha);

#endif  /* DERICHE_H */
